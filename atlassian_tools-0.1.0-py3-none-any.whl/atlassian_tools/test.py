def my_print(name):
    print(f"hello world {name}")
